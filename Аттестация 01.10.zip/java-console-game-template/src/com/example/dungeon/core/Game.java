package com.example.dungeon.core;

import com.example.dungeon.model.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Game {
    private final GameState state = new GameState();
    private final Map<String, Command> commands = new LinkedHashMap<>();

    static {
        WorldInfo.touch("Game");
    }

    public Game() {
        registerCommands();
        bootstrapWorld();
    }

    private void registerCommands() {
        commands.put("help", (ctx, a) -> System.out.println("Команды: " + String.join(", ", commands.keySet())));
        commands.put("gc-stats", (ctx, a) -> {
            Runtime rt = Runtime.getRuntime();
            long free = rt.freeMemory(), total = rt.totalMemory(), used = total - free;
            System.out.println("Память: used=" + used + " free=" + free + " total=" + total);
        });
        commands.put("look", (ctx, a) -> System.out.println(ctx.getCurrent().describe()));
        commands.put("move", (ctx, a) -> {
            if (a.isEmpty()) {
                throw new InvalidCommandException("Укажите направление для перемещения.");
            }
            String direction = a.get(0).toLowerCase();
            Room currentRoom = ctx.getCurrent();
            Room nextRoom = currentRoom.getNeighbors().get(direction);
            if (nextRoom == null) {
                throw new InvalidCommandException("Нет пути в этом направлении: " + direction);
            }
            ctx.setCurrent(nextRoom);
            System.out.println("Вы переместились в комнату: " + nextRoom.getName());
        });
        commands.put("take", (ctx, a) -> {
            if (a.isEmpty()) {
                throw new InvalidCommandException("Укажите предмет, который хотите взять.");
            }
            String itemName = a.get(0);
            Room currentRoom = ctx.getCurrent();
            Optional<Item> itemOpt = currentRoom.getItems().stream()
                    .filter(item -> item.getName().equalsIgnoreCase(itemName))
                    .findFirst();
            if (itemOpt.isPresent()) {
                Item item = itemOpt.get();
                currentRoom.getItems().remove(item);
                ctx.getPlayer().getInventory().add(item);
                System.out.println("Предмет '" + item.getName() + "' добавлен в инвентарь.");
            } else {
                throw new InvalidCommandException("Предмет '" + itemName + "' не найден в этой комнате.");
            }
        });
        commands.put("inventory", (ctx, a) -> {
            List<Item> inventory = ctx.getPlayer().getInventory();
            if (inventory.isEmpty()) {
                System.out.println("Инвентарь пуст.");
            } else {
                System.out.println("Инвентарь:");
                inventory.stream()
                        .forEach(item -> System.out.println("- " + item.getName()));
            }
        });
        commands.put("use", (ctx, a) -> {
            if (a.isEmpty()) {
                throw new InvalidCommandException("Укажите предмет, который хотите использовать.");
            }
            String itemName = a.get(0);
            Player player = ctx.getPlayer();
            Optional<Item> itemOpt = player.getInventory().stream()
                    .filter(item -> item.getName().equalsIgnoreCase(itemName))
                    .findFirst();
            if (itemOpt.isPresent()) {
                Item item = itemOpt.get();
                if (item instanceof Potion) {
                    Potion potion = (Potion) item;
                    player.heal(potion.getHealing());
                    player.getInventory().remove(potion);
                    System.out.println("Вы использовали " + potion.getName() + ". Здоровье увеличено.");
                } else {
                    throw new InvalidCommandException("Этот предмет нельзя использовать.");
                }
            } else {
                throw new InvalidCommandException("Предмет '" + itemName + "' не найден в инвентаре.");
            }
        });
commands.put("fight", (ctx, a) -> {
            Room currentRoom = ctx.getCurrent();
            Monster monster = currentRoom.getMonster();
            if (monster == null) {
                throw new InvalidCommandException("Здесь нет врага для боя.");
            }
            Player player = ctx.getPlayer();
            System.out.println("Бой начался: вы против " + monster.getName());
            while (player.getHp() > 0 && monster.getHealth() > 0) {
                int damageToMonster = player.getAttack() + new Random().nextInt(3);
                monster.decreaseHealth(damageToMonster);
                System.out.println("Вы нанесли " + damageToMonster + " урона " + monster.getName());
                if (monster.getHealth() <= 0) {
                    System.out.println("Вы победили " + monster.getName());
                    currentRoom.setMonster(null);
                    break;
                }
                int damageToPlayer = monster.getAttack() + new Random().nextInt(3);
                player.decreaseHealth(damageToPlayer);
                System.out.println(monster.getName() + " нанёс вам " + damageToPlayer + " урона");
                if (player.getHp() <= 0) {
                    System.out.println("Вы окочурились...");
                    System.exit(0);
                }
            }
        });
        commands.put("save", (ctx, a) -> SaveLoad.save(ctx));
        commands.put("load", (ctx, a) -> SaveLoad.load(ctx));
        commands.put("scores", (ctx, a) -> SaveLoad.printScores());
        commands.put("exit", (ctx, a) -> {
            System.out.println("Хорошо, что это не VIM... Пока!");
            System.exit(0);
        });
    }

    private void bootstrapWorld() {
        Player hero = new Player("Сисадмин", 25, 5);
        state.setPlayer(hero);

        Room square = new Room("Проходная", "Тихий сап охранника... Поодаль слышен разговор из переговорной.");
        Room forest = new Room("Серверная", "Подсобное помещение с тряпками и шваброй.");
        Room cave = new Room("Бухгалтерия", "Темно и сыро.");
        square.getNeighbors().put("north", forest);
        forest.getNeighbors().put("south", square);
        forest.getNeighbors().put("east", cave);
        cave.getNeighbors().put("west", forest);

        forest.getItems().add(new Potion("RedBull_175ml", 5));
        forest.setMonster(new Monster("МикроТик RB750", 1, 8));

        state.setCurrent(square);
    }

    public void run() {
        System.out.println("DungeonMini (TEMPLATE). 'help' — команды.");
        try (BufferedReader in = new BufferedReader(new InputStreamReader(System.in))) {
            while (true) {
                System.out.print("> ");
                String line = in.readLine();
                if (line == null) break;
                line = line.trim();
                if (line.isEmpty()) continue;
                List<String> parts = Arrays.asList(line.split("\\s+"));
                String cmd = parts.get(0).toLowerCase(Locale.ROOT);
                List<String> args = parts.subList(1, parts.size());
                Command c = commands.get(cmd);
                try {
                    if (c == null) throw new InvalidCommandException("Неизвестная команда: " + cmd);
                    c.execute(state, args);
                    state.addScore(1);
                } catch (InvalidCommandException e) {
                    System.out.println("Ошибка: " + e.getMessage());
                } catch (Exception e) {
                    System.out.println("Непредвиденная ошибка: " + e.getClass().getSimpleName() + ": " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка ввода/вывода: " + e.getMessage());
        }
    }
}