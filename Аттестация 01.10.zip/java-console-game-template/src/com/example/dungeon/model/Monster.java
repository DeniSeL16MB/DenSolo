package com.example.dungeon.model;

public class Monster extends Entity {
    private int level;

    public Monster(String name, int level, int hp) {
        super(name, hp);
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getHealth() {
        return this.getHp();
    }

    public void decreaseHealth(int amount) {
        this.setHp(this.getHp() - amount);
        if (this.getHp() < 0) this.setHp(0);
    }

    public int getAttack() {
        return level * 3 + 2;
    }
}