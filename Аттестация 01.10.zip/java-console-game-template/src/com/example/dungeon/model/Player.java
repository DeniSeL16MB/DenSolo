package com.example.dungeon.model;

import java.util.*;

public class Player extends Entity {
    private int attack;
    private final List<Item> inventory = new ArrayList<>();

    public Player(String name, int hp, int attack) {
        super(name, hp);
        this.attack = attack;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public List<Item> getInventory() {
        return inventory;
    }

    public void heal(int amount) {
        this.setHp(this.getHp() + amount);
    }
    public void decreaseHealth(int damage) {
    this.setHp(this.getHp() - damage);
    if (this.getHp() < 0) this.setHp(0);
    }
}