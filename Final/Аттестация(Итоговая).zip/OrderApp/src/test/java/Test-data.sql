INSERT INTO product (description, price, quantity, category) VALUES
('Laptop ASUS', 70000, 10, 'Electronics'),
('Smartphone Samsung', 50000, 15, 'Electronics'),
('Headphones Sony', 5000, 50, 'Accessories'),
('Monitor LG', 15000, 8, 'Electronics'),
('Keyboard Logitech', 3000, 20, 'Accessories'),
('Printer HP', 25000, 5, 'Office Equipment'),
('Desk Chair', 8000, 12, 'Furniture'),
('Table Lamp', 2000, 25, 'Lighting'),
('Bookcase', 12000, 4, 'Furniture'),
('External HDD', 6000, 30, 'Electronics');

INSERT INTO customer (first_name, last_name, phone, email) VALUES
('Ivan', 'Ivanov', '+79991112233', 'ivan@mail.com'),
('Maria', 'Petrova', '+79997773322', 'maria@mail.com'),
('Alex', 'Sidorov', '+79992221111', 'alex@mail.com'),
('Olga', 'Kuznetsova', '+79995554433', 'olga@mail.com'),
('Peter', 'Johnson', '+79998887766', 'peter@mail.com'),
('Laura', 'Smith', '+79997775544', 'laura@mail.com'),
('Oleg', 'Popov', '+79996663322', 'oleg@mail.com'),
('Anna', 'Vasileva', '+79994445566', 'anna@mail.com'),
('Nikolay', 'Morozov', '+79993332211', 'nikolay@mail.com'),
('Elena', 'Smirnova', '+79992223344', 'elena@mail.com');

INSERT INTO order_status (name) VALUES
('Pending'),
('Processing'),
('Shipped'),
('Delivered'),
('Cancelled'),
('On Hold'),
('Returned'),
('Completed'),
('Awaiting Payment'),
('Refunded');

INSERT INTO "order" (product_id, customer_id, quantity, status_id) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2),
(3, 3, 3, 3),
(4, 4, 1, 4),
(5, 5, 2, 1),
(6, 6, 1, 2),
(7, 7, 3, 3),
(8, 8, 2, 4),
(9, 9, 1, 5),
(10, 10, 5, 1);