package com.example;

import java.sql.*;
import java.io.InputStream;
import java.util.Properties;

public class App {

    public static void main(String[] args) {
        Properties props = new Properties();
        try (InputStream input = App.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (input == null) {
                System.out.println("Файл application.properties не найден в classpath");
                return;
            }
            props.load(input);
        } catch (Exception e) {
            System.out.println("Ошибка чтения настроек: " + e.getMessage());
            return;
        }

        String url = props.getProperty("db.url");
        String user = props.getProperty("db.user");
        String password = props.getProperty("db.password");

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            conn.setAutoCommit(false);

            insertProduct(conn);
            insertCustomer(conn);
            createOrder(conn);
            printLastOrders(conn);
            updateProductPriceAndQuantity(conn);
            deleteTestRecords(conn);

            conn.commit();
        } catch (SQLException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    private static void insertProduct(Connection conn) throws SQLException {
        String sql = "INSERT INTO product (description, price, quantity, category) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, "Test Product");
            ps.setBigDecimal(2, new java.math.BigDecimal("999.99"));
            ps.setInt(3, 10);
            ps.setString(4, "TestCategory");
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                System.out.println("Добавлен товар ID=" + rs.getInt(1));
            }
        }
    }

    private static void insertCustomer(Connection conn) throws SQLException {
        String sql = "INSERT INTO customer (first_name, last_name, phone, email) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, "Test");
            ps.setString(2, "Buyer");
            ps.setString(3, "+79991112233");
            ps.setString(4, "testbuyer@mail.com");
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                System.out.println("Добавлен покупатель ID=" + rs.getInt(1));
            }
        }
    }

    private static void createOrder(Connection conn) throws SQLException {
        String sql = "INSERT INTO \"order\" (product_id, customer_id, quantity, status_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, 1);
            ps.setInt(2, 1);
            ps.setInt(3, 2);
            ps.setInt(4, 1);
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                System.out.println("Создан заказ ID=" + rs.getInt(1));
            }
        }
    }

    private static void printLastOrders(Connection conn) throws SQLException {
        String sql = "SELECT o.id, c.first_name, c.last_name, p.description, o.order_date, o.quantity, s.name AS status_name "
                   + "FROM \"order\" o "
                   + "JOIN customer c ON o.customer_id=c.id "
                   + "JOIN product p ON o.product_id=p.id "
                   + "JOIN order_status s ON o.status_id=s.id "
                   + "ORDER BY o.order_date DESC LIMIT 5";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Последние 5 заказов:");
            while (rs.next()) {
                System.out.printf("ID=%d, клиент=%s %s, товар=%s, дата=%s, кол=%d, статус=%s\n",
                        rs.getInt("id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("description"),
                        rs.getTimestamp("order_date").toString(),
                        rs.getInt("quantity"),
                        rs.getString("status_name"));
            }
        }
    }

    private static void updateProductPriceAndQuantity(Connection conn) throws SQLException {
        String updatePrice = "UPDATE product SET price=price+100 WHERE id=?";
        String updateQuantity = "UPDATE product SET quantity=quantity-1 WHERE id=?";
        try (PreparedStatement ps1 = conn.prepareStatement(updatePrice);
             PreparedStatement ps2 = conn.prepareStatement(updateQuantity)) {
            ps1.setInt(1, 1);
            ps1.executeUpdate();
            ps2.setInt(1, 1);
            ps2.executeUpdate();
            System.out.println("Обновлены цена и количество товара ID=1");
        }
    }

    private static void deleteTestRecords(Connection conn) throws SQLException {
        String deleteCustomer = "DELETE FROM customer WHERE email='testbuyer@mail.com'";
        String deleteProduct = "DELETE FROM product WHERE description='Test Product'";
        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(deleteCustomer);
            stmt.executeUpdate(deleteProduct);
            System.out.println("Удалены тестовые записи");
        }
    }
}